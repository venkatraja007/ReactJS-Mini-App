## ReactJS Mini App
# Steps To Run App :-

## npm i
## npm run build
## npm run start

#App Functionality :-
## Initial API call will trigger and result will be List in view .
## Whenever you type search the search value will be maintain in state .
## When you click enter in search box and the api call trigger based on the search term and will display result in view. 

